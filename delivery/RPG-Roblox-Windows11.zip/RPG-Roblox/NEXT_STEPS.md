# Continuação exata — Eldravyn 0.6.0

1. Leia PROGRESSO.md, COMO_JOGAR_NO_STUDIO.md, TESTES_STUDIO.md e docs/ELDRAVYN.md. Não recomece o projeto. Dois Places, ProjectId `ProjectMedievalRPG`, DataStore `MedievalRPG_v1`, raças e IDs legados foram preservados.
2. Prioridade seguinte: executar a matriz curta no Roblox Studio, a partir dos dois `.rbxlx` e do comando `PrepareStudio()`. Salvar cada cenário após geração; o build Rojo contém código e não Terrain pré-gravado. A nuvem Linux não executou o Studio.
3. Começar por spawn/criação, portas/caminhos, tutorial/parry e duas dungeons solo; depois dois/quatro clientes e mobile. Registrar Output e passos para reproduzir antes de alterar os sistemas já cobertos.
4. Prévia usa atributo `StudioSessionPreview=true`, reconhecido exclusivamente no Studio: não salva nem sorteia raça temporária. `PrepareStudio({Persistent=true})` habilita o teste real com APIs em Experience dedicada. Publicado continua exigindo DataStore e IDs oficiais de ambos os Places.
5. Expedições: 10/20 andares estáticos gerados no editor, encontros ativados por andar, uma tentativa por servidor reservado, espera de até 90 s pelo grupo. Melhor andar/recompensa confirmados no portal; nova tentativa começa no andar 1. Sete salas legadas permanecem. Não trocar tickets persistentes por confiança em TeleportData.
6. Não ativar produtos, inventar IDs ou combinações de fusão. Pacote iniciante ~300/troca de classe ~100 são propostas desativadas; 150/79/149 existentes também continuam IDs 0. Sons próprios aguardam upload autorizado; poses procedurais não equivalem a animação profissional homologada.
7. Se continuar apenas na nuvem, priorizar novos erros reproduzíveis de API, concorrência e fluxo, sem alegar validação visual/financeira. Benchmarks de 11.888 Parts/135 NPCs/300 árvores são contagem simulada, não promessa de FPS.
8. Depois de mudanças reais: `python3 scripts/check.py`, revisar logs, atualizar PROGRESSO/TEST_RESULTS, `python3 scripts/package.py`; copiar pacote e hashes para delivery. A entrega GitHub nesta branch já foi autorizada; não alterar main ou publicar no Roblox sem instrução específica.

Não usar links /workspace ou sandbox para download: falharam para este usuário. A entrega funcional anterior foi via URL raw do GitHub da branch `codex/rpg-quality-delivery-20261024`.
